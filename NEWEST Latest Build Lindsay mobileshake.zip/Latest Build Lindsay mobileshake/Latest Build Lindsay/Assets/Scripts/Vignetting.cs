﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Vignetting : MonoBehaviour {

	public Image vignetting1;
	public Image vignetting2;
    public Image vignetting3;
    public Image vignetting4;

	// Use this for initialization
	void Start () {
		//vignetting1.fillAmount = 0.0f;
	}
	
	// Update is called once per frame
	void Update () {
        GameObject puddleFall = GameObject.Find("Puddle Example Brian");
        Puddle fall = (Puddle)puddleFall.GetComponent(typeof(Puddle));

		GameObject gethealth = GameObject.Find("Player");
		CatMove healthget = (CatMove)gethealth.GetComponent(typeof(CatMove));

        //if (fall.playerFallen == true)
       // {
          //  vignetting1.fillAmount += 0.1f;
          //  vignetting2.fillAmount += 0.1f;
           // vignetting3.fillAmount += 0.1f;
           // vignetting4.fillAmount += 0.1f;
       // }

        if (healthget.Collecting == false)
        {
           // Debug.Log("vignetting does nothing");

            vignetting1.fillAmount -= 0.00f;
            vignetting2.fillAmount -= 0.00f;
            vignetting3.fillAmount -= 0.00f;
            vignetting4.fillAmount -= 0.00f;
        }

        else if (healthget.Collecting == true)
        {
            //Debug.Log("COllecting");
            if (healthget.healthImpactPos == true)
            {
                //Debug.Log("vignetting increase");

                //if (vignetting1.fillAmount <= 1.0f)
                // {
                vignetting1.fillAmount += 0.2f;
                vignetting2.fillAmount += 0.2f;
                vignetting3.fillAmount += 0.2f;
                vignetting4.fillAmount += 0.2f;

                healthget.Collecting = false;
                // }

            }

            if (healthget.healthImpactNeg == true)
            {
                //Debug.Log("vignetting decrease");

                vignetting1.fillAmount -= 0.5f;
                vignetting2.fillAmount -= 0.5f;
                vignetting3.fillAmount -= 0.5f;
                vignetting4.fillAmount -= 0.5f;

                healthget.Collecting = false;
            }
        }

        


		if(Input.GetKeyDown (KeyCode.UpArrow)) {
			if(vignetting1.fillAmount <= 1.0f){
			vignetting1.fillAmount += 0.03f;
			}
        }

        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            if (vignetting1.fillAmount >= 0.0f)
            {
                vignetting1.fillAmount -= 0.1f;
            }
        }
		
	}
}
