﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class SeeSawController : MonoBehaviour
{
    public GameObject Rock;
    public Transform StartPathNode;
    public Transform EndPathNode;
    bool shaken;
    bool canShake;
    public AudioClip SeesawSound;
    AudioSource audio;

    public Text isShaking;

    bool startShake;
    bool shakeComplete;
    int shakeCount;
    //public int setShakes;

    float accelMax;
    double accel;

    // Use this for initialization
    void Start()
    {
        accelMax = 0.6f;
        //setShakes = 3;
        accel = Input.acceleration.y;
        audio = GetComponent<AudioSource>();
       // shaken = false;
        //Seesaw = false;
    }

    // Update is called once per frame
    void Update()
    {
        accel = Input.acceleration.y;
        

            //Debug.Log(startShake);
            isShaking.text = "ShakeCount: "+ shakeCount;

            if (canShake == true)
            {
                //canShake = true;
                ShakingDevice();
                
                    if (shakeCount == 3)         //if number of shakes equals 3
                    {
                        //isShaking.text = "Uppy" + shaken;
                        Rock.GetComponent<RockController>().activate = true;
                        shakeCount = 0;
                        canShake = false;

                    }
                
            }
    }

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            canShake = true;
            if (Rock != null)
            {
                //StartPathNode = GameObject.FindGameObjectWithTag("Player").GetComponent<Trajectory>().startpoint; //Take this objects StartPathNode Transform and assign it to the trajectory component on the player
                //zEndPathNode = GameObject.FindGameObjectWithTag("Player").GetComponent<Trajectory>().endpoint;     //Take this ibjects EndPathNode Transform and assign it to the trajectory component on the player
                //Debug.Log("I am Found");
                audio.PlayOneShot(SeesawSound);

                GameObject start = GameObject.Find("Player");           //Changed these, Unity wasn't happy after cat was imported.
                Trajectory others = (Trajectory)start.GetComponent(typeof(Trajectory));
                others.startpoint = StartPathNode;

                GameObject end = GameObject.Find("Player");
                Trajectory endtraj = (Trajectory)end.GetComponent(typeof(Trajectory));
                endtraj.endpoint = EndPathNode;
            }



        }
        else canShake = false;
        /* if the player has collided with the see saw then look for the attached gameobject and destroy it. This should be assigned in the inspector
         This will be changed later so that when the screen is shaken it should fall*/
    }

    public void ShakingDevice()
    {
       
        if (accel <= -0.5)
        {
            shaken = false;
        }

        if (accel >= -0.3)          //Device tipped on its side (shaken)
        {
            startShake = true;
           // isShaking.text = "startShaking";
            
        }

        if (startShake == true)
        {
            if (accel <= -0.5)
            {
                shaken = true;
                startShake = false;
                shakeComplete = true;
            }
        }

        if (shakeComplete == true)
        {
            shakeCount++;
            shakeComplete = false;
        }

        if (Input.GetKeyDown(KeyCode.A))        //use for debugging, increase shakes to activate seesaw by pressing A key
            shakeComplete = true;
        if (Input.GetKeyDown(KeyCode.S))
            accel = -0.3;

        
    }
}
