﻿using UnityEngine;
using System;
using System.Collections;
using UnityEngine.UI;

public enum SoundType {left1, left2, left3, right1, right2, right3 };

public class CatMove : MonoBehaviour
{
    public float moveSpeed;
    public float jumpSpeed;
    public float rotateSpeed;

    public AudioClip sound;

	public AudioClip walkingSound;
	public AudioClip walkingSound2;
	public AudioClip walkingSound3;
	public AudioClip walkingSound4;
	public AudioClip walkingSound5;
	public AudioClip walkingSound6;


    public AudioClip jumpSound;
    CharacterController controller;
    AudioSource audio;
    SoundType soundlor;
    public float gravity = 9.8f;
    protected bool jump;
    protected bool doublejump;
    Vector3 currentmovement;

    float MaxHealth;
    float currHealth;
   
    int soundTimer;
	bool onGrass;
	bool onWater;

    // Use this for initialization

    void Start()
    {
        moveSpeed = 8.0f;
        jumpSpeed = 10.0f;
        rotateSpeed = 160;
        soundTimer = 0;
        controller = GetComponent<CharacterController>();
        audio = GetComponent<AudioSource>();
        jump = false;
        doublejump = false;
		onGrass = true;
		onWater = false;
       //soundType = SoundType.left1;
        
    }
    public void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "insulin")
        {
           
            audio.PlayOneShot(sound);

            Destroy(other.gameObject);
        }

        else if (other.gameObject.tag == "Food")
        {
            
            Destroy(other.gameObject);
        }

		if (other.gameObject.tag == "Grass") {
			onGrass = true;
			onWater = false;
		} 

		if (other.gameObject.tag == "Water") {
			onWater = true;
			onGrass = false;
		} 

    }
    // Update is called once per frame
    void Update()
    {
        currentmovement.x = 1;
        currentmovement = new Vector3(currentmovement.x * moveSpeed, currentmovement.y, currentmovement.z);
        
        if (!controller.isGrounded)
        {
            currentmovement -= new Vector3(0, gravity * Time.deltaTime * 2, 0);
        }
        else
            currentmovement.y = 0;

        if (Input.GetKeyDown(KeyCode.Space)) 	//jump
        {
            if (controller.isGrounded)
            {
                audio.PlayOneShot(jumpSound);
                
                currentmovement.y = jumpSpeed;

                doublejump = true;

            }
            else
            {
                if (doublejump)
                {
                    doublejump = false;
                    currentmovement.y = jumpSpeed;
                    audio.PlayOneShot(jumpSound);
                }
            }
        }
        controller.Move(currentmovement * Time.deltaTime);

        //}
        
		if (controller.isGrounded && onGrass == true)
            {
            //PLAY SOUND WHEN ON GRASS
				soundTimer++;
                audioPlayGrass ();
            }

		else if (onWater == true)
		{
			//soundTimer++;
			audioPlayWater ();
		}


    }

	void audioPlayGrass()
	{
        //PLAY A NEW RANDOM SOUND WHEN SOUND TIMER REACHES THE NEXT 7
        switch (soundTimer) {
		case 7: foot(RandomSound()); break;
		case 14: foot(RandomSound());break;
        case 21: foot(RandomSound()) ; break;
		case 28 :foot(RandomSound()); break;
		case 35: foot(RandomSound());break;
        case 42: foot(RandomSound()); break;
		case 43: soundTimer = 0; break;
		default: break;
		}

	}

    void foot(SoundType soundType)
    {
        switch(soundType)
        {
            //PLAY SOUND FOR EACH FOOT AND THE DIFFERENT TYPES
            case SoundType.left1: audio.PlayOneShot(walkingSound); break;
            case SoundType.left2: audio.PlayOneShot(walkingSound2); break;
            case SoundType.left3: audio.PlayOneShot(walkingSound3); break;
            case SoundType.right1: audio.PlayOneShot(walkingSound4); break;
            case SoundType.right2: audio.PlayOneShot(walkingSound5); break;
            case SoundType.right3: audio.PlayOneShot(walkingSound6); break;
            default: break;
        }
    }


    private SoundType RandomSound()
    {
        //RETURNS RANDOM SOUND TYPE
        return (SoundType)(UnityEngine.Random.Range(0, Enum.GetNames(typeof(SoundType)).Length));
    }

	void audioPlayWater()
	{
		audio.PlayOneShot (sound);
	}
}

