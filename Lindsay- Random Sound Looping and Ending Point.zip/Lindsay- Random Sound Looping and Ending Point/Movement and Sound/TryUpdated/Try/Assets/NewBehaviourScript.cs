﻿using UnityEngine;
using System.Collections;

public class NewBehaviourScript : MonoBehaviour {

	MeshRenderer visible;
	// Use this for initialization
	void Start () {
		visible = GetComponent<MeshRenderer> ();
	}
	
	// Update is called once per frame
	void Update () {
		visible.enabled = false;
	}

    void OnTriggerEnter(Collider coll)
    {
        if (coll.gameObject.tag == "Player")
        {
            Application.LoadLevel(1);
        }
    }
}
