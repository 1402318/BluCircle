﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;

public class Swinging2 : MonoBehaviour {

	public Rigidbody body1;
	public float LeftSwingRange;//left swing range
	public float RightSwingRange;//right swing range
	public float velocity = 1;//speed of swing
	// Use this for initialization
	void Start () 
	{
		body1 = GetComponent<Rigidbody>();//finds rigid body
		body1.angularVelocity = velocity;//applies velocity to body
	}
	
	// Update is called once per frame
	void Update () 
	{
		Go();
	}
	public void Go()//Swinging for obstical swing
	{
		if (transform.rotation.x > 0 && transform.rotation.x < RightSwingRange && (body1.angularVelocity > 0)&& body1.angularVelocity < velocity) 
		{
			body1.angularVelocity = velocity;
		}
		else if (transform.rotation.x < 0 && transform.rotation.x > LeftSwingRange && (body1.angularVelocity < 0)&& body1.angularVelocity > velocity * -1) 
		{
			body1.angularVelocity = velocity * -1;
		}
	}
}