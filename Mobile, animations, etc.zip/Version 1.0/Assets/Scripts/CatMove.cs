﻿using UnityEngine;
using System;
using System.Collections;
using UnityEngine.UI;

public enum SoundType {left1, left2, left3, right1, right2, right3 };

public class CatMove : MonoBehaviour
{

    public float moveSpeed;
    public float jumpSpeed;
    public float rotateSpeed;
	bool onGrass;
	bool onWater;

	/// Sounds	/// 
    public AudioClip sound;
    public AudioClip jumpSound;
	public AudioClip walkingSound;
	public AudioClip walkingSound2;
	public AudioClip walkingSound3;
	public AudioClip walkingSound4;
	public AudioClip walkingSound5;
	public AudioClip walkingSound6;

	public GameObject ground;
    CharacterController controller;
    AudioSource audio;

    public float gravity;// = 9.8f;
    protected bool jump;
    protected bool doublejump;
    Vector3 currentmovement;

    float MaxHealth;
    float currHealth;
    public Slider healthBarSlider;  //reference for slider
    
	int soundTimer;

    private Animator anim;
	Touch myTouch ;
    public Transform respawnPoint;

    // Use this for initialization

    void Start()
    {
        //moveSpeed = 3.0f; // J.G. Changed from 8 to 3 for testing // this value is not actually used anywhere. 
        jumpSpeed = 7.0f; // Changed from 5 to 7 -JG-
        rotateSpeed = 160;
        soundTimer = 0;
        controller = GetComponent<CharacterController>();
        audio = GetComponent<AudioSource>();
        jump = false;
        doublejump = false;

		onGrass = true;
		onWater = false;

        anim = GetComponent<Animator>();
        if (respawnPoint == null)
        {
            Debug.Log("Cat does not have a spawn point");
            respawnPoint = GameObject.FindGameObjectWithTag("SpawnPoint").transform;
        }
        ResetPosition();

		myTouch = Input.GetTouch(0);
    }
    public void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "insulin")
        {
            healthBarSlider.value += 0.8f;
            audio.PlayOneShot(sound);

            Destroy(other.gameObject);
        }

        else if (other.gameObject.tag == "Food")
        {
            healthBarSlider.value -= 0.3f;
            Destroy(other.gameObject);
        }

		if (other.gameObject.tag == ground.tag) {
			onGrass = true;
			onWater = false;
		} 
    }

    public void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "SeeSaw")
        {
            moveSpeed = 0;
            Debug.Log("I am sitting on a seesaw, yay!");
        }
        /*The above if check is ran when the object(cat) triggers with the seesaw trigger on a StartPathNode object
         * This stops the cat moving so that it can travel along the curved path. The next action occurs on RockController 
         There is also another trigger check on the see saw object which checks for the player.. see SeeSawController*/
        
        if(other.gameObject.tag == "EndPathNode")
        {
            GetComponent<Trajectory>().DeactivateFlyby();
            moveSpeed = 3; //this should be changed *Jamie, Changed from 1 to 3*
            Debug.Log("I made it mom!");
        }
    }
    // Update is called once per frame
    void Update()
    {
        currentmovement.z = moveSpeed;

        currentmovement = new Vector3(0, currentmovement.y, currentmovement.z);
        //healthBarSlider.value -= .00011f;

        if (!controller.isGrounded)
        {

            currentmovement -= new Vector3(0, gravity * Time.deltaTime * 2, 0);
            anim.SetBool("Jump", false);
        }
        else
        {
            currentmovement.y = 0;
            anim.SetFloat("Run", moveSpeed);
        }
	
		if (Input.GetMouseButtonDown (0)) {
			if (controller.isGrounded) {
				audio.PlayOneShot (jumpSound);
				// healthBarSlider.value -= .011f;
				currentmovement.y = jumpSpeed;
				anim.SetBool ("Jump", true);
				doublejump = true;
				
			} else {
				if (doublejump) {
					doublejump = false;
					currentmovement.y = jumpSpeed;
					audio.PlayOneShot (jumpSound);
				}
			}
			Debug.Log ("Jumpy jumpy jumparoo");
		}



        controller.Move(currentmovement * Time.deltaTime);

		if (controller.isGrounded && onGrass == true)
		{
			//PLAY SOUND WHEN ON GRASS
			if(onGrass == true)
				Debug.Log("Grass");
			soundTimer+=Time.deltaTime;
			if (soundTimer >=20)
			{
				audioPlayGrass();
				soundTimer = 0;
			}

		}
    }

    public void ResetPosition()
    {
        if (respawnPoint != null)
        {
            Debug.Log("position of current spawnpoint" + respawnPoint.transform.position);
            this.gameObject.transform.position = respawnPoint.transform.position;
        }
    }

	public void Jump()
	{
		if (controller.isGrounded) {
			audio.PlayOneShot (jumpSound);
			// healthBarSlider.value -= .011f;
			currentmovement = jumpSpeed * Vector3.up *Time.deltaTime ;
			anim.SetBool ("Jump", true);
			doublejump = true;
				
		} 
		else {
			if (doublejump) {
				doublejump = false;
				currentmovement.y = jumpSpeed;
				audio.PlayOneShot (jumpSound);
			}
		}
	}

	private SoundType RandomSound()
	{
		//RETURNS RANDOM SOUND TYPE
		return (SoundType)(UnityEngine.Random.Range(0, Enum.GetNames(typeof(SoundType)).Length));
	}

	void audioPlayGrass()
	{
		//PLAY A NEW RANDOM SOUND WHEN SOUND TIMER REACHES THE NEXT 7

		foot(RandomSound()); 

		
	}
	
	void foot(SoundType soundType)
	{
		switch(soundType)
		{
			//PLAY SOUND FOR EACH FOOT AND THE DIFFERENT TYPES
		case SoundType.left1: audio.PlayOneShot(walkingSound); Debug.Log ("One"); break;
		case SoundType.left2: audio.PlayOneShot(walkingSound2); Debug.Log ("Two");break;
		case SoundType.left3: audio.PlayOneShot(walkingSound3); Debug.Log ("Three");break;
		case SoundType.right1: audio.PlayOneShot(walkingSound4); Debug.Log ("Four");break;
		case SoundType.right2: audio.PlayOneShot(walkingSound5); Debug.Log ("Five");break;
		case SoundType.right3: audio.PlayOneShot(walkingSound6); Debug.Log ("Six");break;
		default: break;
		}
	}
	



}

