﻿using UnityEngine;
using System.Collections;
using System;

public class GrassSounds : MonoBehaviour {

	AudioSource audio;
	public AudioClip walkingSound;
	public AudioClip walkingSound2;
	public AudioClip walkingSound3;
	public AudioClip walkingSound4;
	public AudioClip walkingSound5;
	public AudioClip walkingSound6;

	int soundTimer;


	// Use this for initialization
	void Start () {
		audio = GetComponent<AudioSource>();
		soundTimer = 0;
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void OnTriggerEnter(Collider other)
	{
		Debug.Log ("Touchy");
		if (other.gameObject.tag == "Player") {
			soundTimer++;
			if (soundTimer == 10) {
				audioPlayGrass ();
			}
			//soundTimer = 0;
		}


	}

	private SoundType RandomSound()
	{
		//RETURNS RANDOM SOUND TYPE
		return (SoundType)(UnityEngine.Random.Range(0, Enum.GetNames(typeof(SoundType)).Length));
	}
	
	void audioPlayGrass()
	{
		//PLAY A NEW RANDOM SOUND WHEN SOUND TIMER REACHES THE NEXT 7
		
		foot(RandomSound()); 
		
		
	}
	
	void foot(SoundType soundType)
	{
		switch(soundType)
		{
			//PLAY SOUND FOR EACH FOOT AND THE DIFFERENT TYPES
		case SoundType.left1: audio.PlayOneShot(walkingSound); Debug.Log ("One"); break;
		case SoundType.left2: audio.PlayOneShot(walkingSound2); Debug.Log ("Two");break;
		case SoundType.left3: audio.PlayOneShot(walkingSound3); Debug.Log ("Three");break;
		case SoundType.right1: audio.PlayOneShot(walkingSound4); Debug.Log ("Four");break;
		case SoundType.right2: audio.PlayOneShot(walkingSound5); Debug.Log ("Five");break;
		case SoundType.right3: audio.PlayOneShot(walkingSound6); Debug.Log ("Six");break;
		default: break;
		}
	}
}
