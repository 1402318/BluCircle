﻿using UnityEngine;
using System.Collections;

public class EndGame : MonoBehaviour {
	public int wait;
	public GameObject endScreen;
	Debugger others;
	// Use this for initialization
	void Start () {
		endScreen.SetActive (false);
		others = (Debugger)gameObject.GetComponent(typeof(Debugger));
	}
	
	// Update is called once per frame
	void Update () {

	}

	void OnTriggerEnter(Collider collide)
	{
		if (collide.gameObject.tag == "Player") {
			//others.GoToNextLevel("Main Menu", wait);
            //waitTime(wait);
			//endScreen.SetActive (true);
			//Time.timeScale = 0;

            StartCoroutine(waitTime(wait));
		}
	}

    private IEnumerator waitTime(int wait)
    {
        yield return new WaitForSeconds(wait);

        endScreen.SetActive (true);
        Time.timeScale = 0;
    }

	public void buttonClick()
	{
        Debug.Log("Button CLicked");
		others.GoToNextLevel("Main Menu", wait);
	}


}
