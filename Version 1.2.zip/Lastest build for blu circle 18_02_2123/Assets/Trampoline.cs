﻿using UnityEngine;
using System.Collections;

public class Trampoline : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnCollisionStay(Collision collide)
    {
        if (collide.gameObject.tag == "Player")
        {
            
        }
    }
}
