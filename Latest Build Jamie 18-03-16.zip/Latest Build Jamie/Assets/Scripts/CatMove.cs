﻿using UnityEngine;
using System;
using System.Collections;
using UnityEngine.UI;

public enum SoundType {left1, left2, left3, right1, right2, right3};
public enum State { normal, trampoline, seesaw };   //changed into states

public class CatMove : MonoBehaviour
{
    bool onTrampoline;
    bool onSeesaw;
    public bool Collecting;
    public Transform particlePos;
    public Transform particle;
	public float moveSpeed;
	public float jumpSpeed;
	public float rotateSpeed;
	bool onGrass;
	bool onWater;
    public float trampolineSpeed;
    public bool SwingCall = false;
	
	/// Sounds	/// 
	public AudioClip sound;
	public AudioClip jumpSound;
	public AudioClip walkingSound;
	public AudioClip walkingSound2;
	public AudioClip walkingSound3;
	public AudioClip walkingSound4;
	public AudioClip walkingSound5;
	public AudioClip walkingSound6;
	
	public GameObject ground;
	CharacterController controller;
	AudioSource audio;
	
	public float gravity;// = 9.8f;
	protected bool jump;
	protected bool doublejump;
	Vector3 currentmovement;
	
	public bool healthImpactPos, healthImpactNeg;
	public float currHealth;
	public Slider healthBarSlider;  //reference for slider

	int soundTimer;
	
	private Animator anim;
	Touch myTouch;
	public Transform respawnPoint;
    public Transform sBase;

    float lockPosition = 0;
	
	// Use this for initialization
	
	void Start()
	{
		//jumpSpeed = 7.0f; // Changed from 5 to 7 -JG-
		rotateSpeed = 160;
		soundTimer = 0;
		controller = GetComponent<CharacterController>();
		audio = GetComponent<AudioSource>();
		jump = false;
		doublejump = false;
        healthImpactPos = false;
        healthImpactNeg = false;
        Collecting = false;
		onGrass = true;
		onWater = false;
		
		anim = GetComponent<Animator>();
		if (respawnPoint == null)
		{
			Debug.Log("Cat does not have a spawn point");
			respawnPoint = GameObject.FindGameObjectWithTag("SpawnPoint").transform;
		}
		ResetPosition();
	}

	public void OnTriggerEnter(Collider other)
	{
        if (other.gameObject.tag == "SeeSaw")
        {
            onSeesaw = true;
            //Debug.Log("I am sitting on a seesaw, yay!");
        }

        else onSeesaw = false;

        if (other.gameObject.tag == "Trampoline")
        {
            onTrampoline = true;
            // onSeesaw = false;
            //Debug.Log("I am sitting on a seesaw, yay!");
        }
        else onTrampoline = false;


		if(other.gameObject.tag == "Trigger")
		{
			moveSpeed = 1;
			GetComponent<Trajectory>().ActivateFlyby();
			SwingCall = false;
			Debug.Log("I am sitting on a swing, yay!");
		}

		/*The above if check is ran when the object(cat) triggers with the seesaw trigger on a StartPathNode object
         * This stops the cat moving so that it can travel along the curved path. The next action occurs on RockController 
         There is also another trigger check on the see saw object which checks for the player.. see SeeSawController*/
		
		if(other.gameObject.tag == "EndPathNode")
		{
			GetComponent<Trajectory>().DeactivateFlyby();
            anim.SetBool("Collision", false);
			moveSpeed = 3; //this should be changed *Jamie, Changed from 1 to 3*
			Debug.Log("I made it mom!");
		}

        if (other.gameObject.tag == "Food")
        {
            currHealth += 3;
            healthImpactPos = true;
            Destroy(other.gameObject);
           // Debug.Log("food pos");
            Collecting = true;

        }

        if (other.gameObject.tag == "Insulin")
        {
            healthImpactNeg = true;
            currHealth -= 5;
            Destroy(other.gameObject);
            Collecting = true;
           // Debug.Log("insulin pos");
        }

        if (other.gameObject.layer == 8)
        {
            Collecting = true;
        }
        else Collecting = false;
      

	}

	// Update is called once per frame
	void Update()       //Update function changed into states
	{
        if (!controller.isGrounded)
        {
            currentmovement -= new Vector3(0, gravity * Time.deltaTime * 2, 0);
            anim.SetBool("Jump", false);
        }
        currentmovement = new Vector3(0, currentmovement.y, currentmovement.z);

        if (onTrampoline == false)
        {
            gameType(State.normal);
        }

        if (onTrampoline == true)
        {

            gameType(State.trampoline);
        }

        if (onSeesaw == true)
        {
            gameType(State.seesaw);
        }

    }



    void trampoline()
    {
       // Debug.Log("Trampoline");
        moveSpeed = 0;
        anim.SetFloat("Run", 0);
        anim.SetBool("Collision", true);
        Vector3 two = new Vector3(0, currentmovement.y, currentmovement.z);
        controller.Move(two * Time.deltaTime);

        if (controller.isGrounded)
        {

            currentmovement.y = trampolineSpeed;
            currentmovement.z = 0;
            anim.SetBool("Jump", true);
            doublejump = true;
        }
        else
        {
            if (doublejump)
            {
                if (Input.GetMouseButtonDown(0))
                {
                    anim.SetBool("Jump", true);
                    currentmovement.y = 15;
                    currentmovement.z = jumpSpeed;
                    doublejump = false;
                }
            }
        }

    }

    void seesaw()
    {
        moveSpeed = 0;
        anim.SetBool("Collision", true);
    }

    void normalGame(){

        //Debug.Log("Normal");
        anim.SetBool("Collision", false);
        if (onSeesaw == false)
        {
            moveSpeed = 3.0f;
        }
        this.transform.position = new Vector3(respawnPoint.position.x, transform.position.y, transform.position.z);
		currentmovement.z = moveSpeed;
		
		currentmovement = new Vector3(0, currentmovement.y, currentmovement.z);
		

		if (!controller.isGrounded)
		{
			
			currentmovement -= new Vector3(0, gravity * Time.deltaTime * 2, 0);
			anim.SetBool("Jump", false);
		}
		else
		{
			currentmovement.y = 0;
			anim.SetFloat("Run", moveSpeed);
		}
		
		if (Input.GetMouseButtonDown (0)) {
			if (controller.isGrounded) {
				audio.PlayOneShot (jumpSound);
				// healthBarSlider.value -= .011f;
				currentmovement.y = jumpSpeed;
				anim.SetBool ("Jump", true);
				doublejump = true;
				
			} else {
				if (doublejump) {
                    Instantiate(particle, particlePos.position, particle.rotation); 
					doublejump = false;
                    
					currentmovement.y = jumpSpeed;
					audio.PlayOneShot (jumpSound);
                    
				}
			}
			Debug.Log ("Jumpy jumpy jumparoo");
		}
        if (Input.GetMouseButtonDown(1))
        {
            ResetPosition();
        }
		
		controller.Move(currentmovement * Time.deltaTime);
		
		if (controller.isGrounded && onGrass == true)
		{
			//PLAY SOUND WHEN ON GRASS
			if(onGrass == true)
			soundTimer++;
			if (soundTimer >=20)
			{
				audioPlayGrass();
				soundTimer = 0;
			}
		}

        if(SwingCall == true)
        {
            Relocate();
          //  SwingCall = false;
        }
	}
	
	public void ResetPosition()
	{
		if (respawnPoint != null)
		{
			//Debug.Log("position of current spawnpoint" + respawnPoint.transform.position.y);
			this.gameObject.transform.position = respawnPoint.transform.position;
		}
	}

    public void SwingCaller()
    {
        Debug.Log("I'm a swing");
    }

    public void Relocate()
    {
        Debug.Log("activate relocate");
        if(sBase != null)
        {
            this.gameObject.transform.position = sBase.transform.position;
            Debug.Log("Freeze!");
        }
    }
		
	private SoundType RandomSound()
	{
		//RETURNS RANDOM SOUND TYPE
		return (SoundType)(UnityEngine.Random.Range(0, Enum.GetNames(typeof(SoundType)).Length));
	}
	
	void audioPlayGrass()
	{
		//PLAY A NEW RANDOM SOUND WHEN SOUND TIMER REACHES THE NEXT 7
		
		foot(RandomSound()); 
	}

    void gameType(State current)
    {
        switch (current)
        {
            case State.normal: normalGame(); break;
            case State.trampoline: trampoline(); break;
            case State.seesaw: seesaw(); break;
            default: normalGame(); break;
        }
    }

	
	void foot(SoundType soundType)
	{
		switch(soundType)
		{
			//PLAY SOUND FOR EACH FOOT AND THE DIFFERENT TYPES
		case SoundType.left1: audio.PlayOneShot(walkingSound);// Debug.Log ("One"); 
            break;
		case SoundType.left2: audio.PlayOneShot(walkingSound2);// Debug.Log ("Two");
            break;
		case SoundType.left3: audio.PlayOneShot(walkingSound3);// Debug.Log ("Three");
            break;
		case SoundType.right1: audio.PlayOneShot(walkingSound4); //Debug.Log ("Four");
            break;
		case SoundType.right2: audio.PlayOneShot(walkingSound5);// Debug.Log ("Five");
            break;
		case SoundType.right3: audio.PlayOneShot(walkingSound6); //Debug.Log ("Six");
            break;
		default: break;
		}
	}
}