﻿using UnityEngine;
using System.Collections;

public class RotatingPodium : MonoBehaviour {
    /*this script will be used to switch textures on cat model */
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
